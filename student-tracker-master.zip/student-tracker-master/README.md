# student-tracker is built using MVC [Model View Controller Pattern] 
